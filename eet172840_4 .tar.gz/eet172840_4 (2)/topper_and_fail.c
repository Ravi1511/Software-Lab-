#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ps2.h>
//inckuded all header files

struct topper_fail
{
    int fail;
    int entry;
    int top;
}tf_1,tf_2;


//this function calculates total marks for section_1
struct topper_fail sect_11()
{

    FILE *fp1;
    int total=0,topper_sec1=0,failed_student_sec1=0,entry;
    float passing_marks = (40*300)/100;
    fp1 = fopen("section_1.txt", "r");
    
   // printf("\n\tEntry_Number\tTotal_Marks\n");
    //printf("---------------------------------\n");
    while (fread(&section_1, sizeof(section_1), 1, fp1))
      {
           int total = section_1.physics+section_1.chemisty+section_1.maths;
            if(total < passing_marks)
                failed_student_sec1++;

            
            if(total > topper_sec1) 
            {
                entry = section_1.entry_number;
                topper_sec1 = total;
            }

      } 
      // printf("\t%d\t\t%d\n ", section_1.entry_number,section_1.physics+section_1.chemisty+section_1.maths);
    

   tf_1.fail = failed_student_sec1;
   tf_1.top = topper_sec1;
   tf_1.entry = entry;
    fclose(fp1);
    return tf_1;

}


//this function calculates total marks for section_1
struct topper_fail sect_21()
{
    
    FILE *fp2;
    int total=0,topper_sec2=0,failed_student_sec2=0,entry;
    float passing_marks = (40*300)/100;
    fp2 = fopen("section_2.txt", "r");


    //printf("\n\tEntry_Number\tTotal_Marks\n");
  //  printf("---------------------------------\n");
    while (fread(&section_2, sizeof(section_2), 1, fp2))
        {
           int total = section_2.physics+section_2.chemisty+section_2.maths;
            if(total < passing_marks)
                failed_student_sec2++;

            
            if(total > topper_sec2) 
            {
                entry = section_2.entry_number;
                topper_sec2 = total;
            }

      } 
       // printf("\t%d\t\t%d\n ", section_2.entry_number,section_2.physics+section_2.chemisty+section_2.maths);
    tf_2.fail = failed_student_sec2;
    tf_2.top = topper_sec2;
    tf_2.entry = entry;
    fclose(fp2);
    return tf_2;

}


//this function calculates total marks for both sections.
void topper_and_fail()
{
    struct topper_fail result_1,result_2;
    result_1 = sect_11();
    result_2 = sect_21();
     
    if(result_1.top > result_2.top) 
        printf("\n\nTopper of the class:  %d    %d\n",result_1.entry,result_1.top);
    else
        printf("\n\nTopper of the class:  %d    %d\n",result_2.entry,result_2.top);

    printf("Number of failed students are: %d\n",result_1.fail+result_2.fail);

    return;

}