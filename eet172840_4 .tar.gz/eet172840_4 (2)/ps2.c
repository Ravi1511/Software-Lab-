#include <stdio.h>
#include <stdlib.h>

#include <ps2.h>




void insert()
{

    //file pointers fp1 and fp2 for section_1.txt and section_2.txt for
    FILE *fp1,*fp2;


	//opening section_1.txt file with a flag to append in it.
    printf("\nSection_1: ");
    fp1 = fopen("section_1.txt", "a");
    printf("Enter Entry_number: ");
    scanf(" %d", &section_1.entry_number);
    printf("Enter Physics Marks: ");
    scanf(" %d", &section_1.physics);
    printf("Enter Chemistry Marks  : ");
    scanf(" %d", &section_1.chemisty);
    printf("Enter Maths Marks: ");
    scanf(" %d", &section_1.maths);

    //opening section_2.txt file with a flag to append in it.
    printf("\n\nSection_2\n ");
    fp2 = fopen("section_2.txt", "a");
    printf("Enter Entry_number: ");
    scanf(" %d", &section_2.entry_number);
    printf("Enter Physics Marks: ");
    scanf(" %d", &section_2.physics);
    printf("Enter Chemistry Marks  : ");
    scanf(" %d", &section_2.chemisty);
    printf("Enter Maths Marks: ");
    scanf(" %d", &section_2.maths);



//writing content into both files.
    fwrite(&section_1, sizeof(section_1), 1, fp1);
    fwrite(&section_2, sizeof(section_2), 1, fp2);
//closing both files.
    fclose(fp1);
    fclose(fp2);

}


//This function displays section_1 data
void display_1()
{

    //fp1 is file pointer for section_1.txt
    FILE *fp1;
    fp1 = fopen("section_1.txt", "r");

    //reading data till all employee entries finished.
    printf("\nEntry_number\tPhysics Marks\tChemistry Marks\tMaths Marks\n");
    printf("\n-----------------------------------------------------------\n");

    while (fread(&section_1, sizeof(section_1), 1, fp1))
        printf("\t%d\t\t%d\t\t%d\t\t%d\n ", section_1.entry_number,section_1.physics,section_1.chemisty,section_1.maths);



    fclose(fp1);
}

//This function displays section_2 data
void display_2()
{

//fp1 is file pointer for section_2.txt
    FILE *fp2;
    fp2 = fopen("section_2.txt", "r");

    printf("\nEntry_number\tPhysics Marks\tChemistry Marks\tMaths Marks\n");
    printf("\n-----------------------------------------------------------\n");

//reading data till all employee entries finished.
    while (fread(&section_2, sizeof(section_2), 1, fp2))
        printf("\t%d\t\t%d\t\t%d\t\t%d\n ", section_2.entry_number,section_2.physics,section_2.chemisty,section_2.maths);



    fclose(fp2);
}



int main()
{

    int c;



    do
    {

        printf("\nEnter 1 for insert: ");
        printf("\nEnter 2 for display data of section_1: ");
        printf("\nEnter 3 for display data of section_2: ");
        printf("\nEnter 4 to print total marks,average marks,topper and number of failed students: ");
        printf("\n\nEnter Choice: ");

        scanf("%d",&c);
        switch(c)
        {
        case 1:
            insert();
            break;

        case 2:
            display_1();
            break;

        case 3:
            display_2();
            break;

        default:
            printf("\nPrinting Entry_number and total_marks of both sections\n");

            break;
        }
    } while(c!=4);


    total_marks();
    topper_and_fail();
     average();

    return 0;


}