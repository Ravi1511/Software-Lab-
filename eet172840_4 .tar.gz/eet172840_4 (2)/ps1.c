
//header files
#include<stdio.h>
#include <stdlib.h>
#include <string.h>



// structure of a record to be entered in employee.txt
struct employee
{
    int EMPLOYEE_ID;
    char EMPLOYEE_NAME[25];
    int AGE;
    float BASIC_SALARY;
} emp_data;

// structure of a record to be entered in salary.txt
struct salary
{

    char EMPLOYEE_NAME[25];
    float TOTAL_SALARY;
} emp_sal;


//function to insert a record in employee.txt file and
// into salary.txt corresponding to employee_name.
void insert()
{

//file pointers fp1 for employee.txt and fp2 for salary.txt
    FILE *fp1,*fp2;
//variables to calculate total salary of employee.
    float bs=0,hra=0,conv=0,tax=0,total_sal=0;

//opening employee.txt file with a flag to append in it.
    fp1 = fopen("employee.txt", "a");
    printf("Enter Employee ID: ");
    scanf(" %d", &emp_data.EMPLOYEE_ID);
    printf("Enter Employee Name: ");
    scanf(" %s", &emp_data.EMPLOYEE_NAME);
    printf("Enter AGE   : ");
    scanf(" %d", &emp_data.AGE);
    printf("Enter BASIC_SALARY : ");
    scanf(" %f", &emp_data.BASIC_SALARY);

//calculating total salary of employee
    bs=emp_data.BASIC_SALARY;
    hra=((50*bs)/100);
    conv=((10*bs)/100);
    tax=((5*bs)/100);
    total_sal=(bs+hra+conv-tax);

//opening salary.txt to enter employee name and total salary.
    fp2 = fopen("salary.txt", "a");
    strcpy(emp_sal.EMPLOYEE_NAME,emp_data.EMPLOYEE_NAME);
    emp_sal.TOTAL_SALARY=total_sal;

//writing content into both files.
    fwrite(&emp_data, sizeof(emp_data), 1, fp1);
    fwrite(&emp_sal, sizeof(emp_sal), 1, fp2);
//closing both files.
    fclose(fp1);
    fclose(fp2);

}


//function to search for existance of employee_name in employee.txt file
int namesearch(char *name)
{

//file pointer for employee.txt
    FILE *fp;
    fp = fopen("employee.txt", "r");

// look into file till it is empty
    while (!feof(fp))
    {

        //start reading data
        fread(&emp_data, sizeof(emp_data), 1, fp);

        //compare name with employee_name of employee.txt file
        //if found then return 1 otherwise return 0.
        if (strcmp(name,emp_data.EMPLOYEE_NAME) == 0)
        {
            fclose(fp);
            return 1;
        }

    }

//name is not in file then return 0.
    fclose(fp);
    return 0;
}


void update()
{
    printf("update\n" );
}


//function to display all data of employee.txt
void display()
{

//fp1 is file pointer for employee.txt
    FILE *fp;
    fp = fopen("employee.txt", "r");
    printf("\nEMPLOYEE_ID\tEMPLOYEE_Name\tAge\tBASIC_SALARY\n");
    printf("\n-----------------------------------------------\n");
//reading data till all employee entries finished.
    while (fread(&emp_data, sizeof(emp_data), 1, fp))
        printf("  %d\t\t%s\t\t%d\t%.2f\n", emp_data.EMPLOYEE_ID, emp_data.EMPLOYEE_NAME,emp_data.AGE,emp_data.BASIC_SALARY);
//closing file.
    fclose(fp);
}

//this function returns name and total salary from salary.txt file
//depending upon the name searched in employee.txt file.
void search()
{

//file pointer fp for salary.txt file and other variable declaration.
    FILE *fp;
    int  record;
    char name[25];

    printf("\nEnter Employee name to search:");
    scanf("%s", &name);

//if record value is 1 ,it means that
//name is available in employee.txt file and if record value
// is 0 then not available.
    record = namesearch(name);
    if (record == 0)
    {
        printf("Name %s is not available in the file\n",name);
        return;
    }
    else
    {
        fp = fopen("salary.txt", "r");
        //read file till we get the record with name in salary.txt file.
        while (fread(&emp_sal, sizeof(emp_sal), 1, fp))
        {

            // strcpy(dummy,emp_sal.EMPLOYEE_NAME);
            if (strcmp(emp_sal.EMPLOYEE_NAME,name)==0)
            {
                //printing name and total salary of employee.
                printf("\nEMPLOYEE_NAME = %s", emp_sal.EMPLOYEE_NAME);
                printf("\nTOTAL_SALARY    = %.2f\n", emp_sal.TOTAL_SALARY);
            }
        }
        fclose(fp);
    }


}


//main function starts here
void main()
{
    int c;

//infinite loop till we break explicitly
    while(1)
    {

        //possible options to enter for user to enter
        printf("\n\tEnter :   \n");
        printf("\n\t1 for insert");
        printf("\n\t2 for Update");
        printf("\n\t3 for Display");
        printf("\n\t4 for Search");
        printf("\n\t5 for exit\n");

        //taking input to select choice
        printf("\nEnter Your Choice:");
        scanf("%d", &c);
        printf("\n");


        switch (c)
        {
        case 1:
            //case 1 for inserting record in employee.txt file.
            insert();
            break;

        case 2:
            //case 2 for updating record in employee.txt file.
            update();
            break;

        case 3:
            //case 3 for displaying record in employee.txt file.
            display();
            break;

        case 4:
            //case 4 for searching a record in employee.txt file ans show
            //its total salary in salary.txt file.
            search();
            break;

        default:
            //to come out from loop or when enter wrong choice.
            printf("\nWrong Choice..exiting now\n");
            exit(1);
            break;

        }

    }



}
