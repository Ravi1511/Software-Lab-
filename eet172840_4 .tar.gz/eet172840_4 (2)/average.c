#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ps2.h>
//inckuded all header files

struct marks
{
    int phy;
    int chem;
    int maths;
};

//this function calculates total marks for section_1
struct marks avg_section_11()
{

    FILE *fp1;
    int marks_phy=0,marks_chem=0,marks_maths=0,number=0;
    struct marks sec_1;
    fp1 = fopen("section_1.txt", "r");

   // printf("\n\tEntry_Number\tTotal_Marks\n");
   // printf("---------------------------------\n");
    while (fread(&section_1, sizeof(section_1), 1, fp1))
    {
        marks_phy  += section_1.physics;
        marks_chem += section_1.chemisty;
        marks_maths += section_1.maths;
        number += 1; 
    }

        //printf("\t%d\t\t%d\n ", marks_phy/number,marks_chem/number,marks_maths/3);
    sec_1.phy = marks_phy/number;
    sec_1.maths = marks_maths/number;
    sec_1.chem = marks_chem/number;

    fclose(fp1);
    return sec_1;

}


//this function calculates total marks for section_1
struct marks avg_section_21()
{

    FILE *fp2;
     int marks_phy=0,marks_chem=0,marks_maths=0,number=0;
    struct marks sec_2;
    fp2 = fopen("section_2.txt", "r");

   // printf("\n\tEntry_Number\tTotal_Marks\n");
   // printf("---------------------------------\n");
    while (fread(&section_2, sizeof(section_2), 1, fp2))
        {
        marks_phy +=section_2.physics;
        marks_chem += section_2.chemisty;
        marks_maths += section_2.maths;
        number += 1; 
        }
        //printf("\t%d\t\t%d\n ", section_2.entry_number,section_2.physics+section_2.chemisty+section_2.maths);
    sec_2.phy = marks_phy/number;
    sec_2.maths = marks_maths/number;
    sec_2.chem = marks_chem/number;

    fclose(fp2);
    return sec_2;

}


//this function calculates total marks for both sections.
void average()
{
    struct marks cal_sec1;
    struct marks cal_sec2;
    cal_sec1=avg_section_11();
    cal_sec2=avg_section_21();
    
    printf("Average Marks in Physics: %d\n",(cal_sec1.phy+cal_sec2.phy)/2);
    printf("Average Marks in chemisty: %d\n",(cal_sec1.chem+cal_sec2.chem)/2);
    printf("Average Marks in maths: %d\n",(cal_sec1.maths+cal_sec2.maths)/2);
    return;

}