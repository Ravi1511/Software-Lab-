
//this function returns total marks of students in both sections.
void total_marks();
void average();
void topper_and_fail();

//structure of student data
struct student
{
    int entry_number;
    int physics;
    int chemisty;
    int maths;
} section_1,section_2;




