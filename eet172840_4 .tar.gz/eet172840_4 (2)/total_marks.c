#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ps2.h>
//inckuded all header files



//this function calculates total marks for section_1
void section_11()
{

    FILE *fp1;
    fp1 = fopen("section_1.txt", "r");
    printf("\nSection 1\n");
    printf("\n\tEntry_Number\tTotal_Marks\n");
    printf("---------------------------------\n");
    while (fread(&section_1, sizeof(section_1), 1, fp1))
        printf("\t%d\t\t%d\n ", section_1.entry_number,section_1.physics+section_1.chemisty+section_1.maths);

    fclose(fp1);
    return;

}


//this function calculates total marks for section_1
void section_21()
{

    FILE *fp2;
    fp2 = fopen("section_2.txt", "r");
    printf("\nSection 2\n");
    printf("\n\tEntry_Number\tTotal_Marks\n");
    printf("---------------------------------\n");
    while (fread(&section_2, sizeof(section_2), 1, fp2))
        printf("\t%d\t\t%d\n ", section_2.entry_number,section_2.physics+section_2.chemisty+section_2.maths);

    fclose(fp2);
    return;

}


//this function calculates total marks for both sections.
void total_marks()
{

    section_11();
    section_21();
    return;

}