#include <stdio.h>
#include <string.h>


void parity(char str[],int len)
{
    int count=0;
    // iterate over string and look for 1 and count number of occurances of 1.
    for(int i=0; i<len; i++)
    {
        if(str[i]=='1')
            count++;
    }

    //Total number of occurances are stored in variable count.
    if(count%2==0)
        str[len]='0';
    //if number of 1's are even then add 0 as parity bit at the end.
    else
        str[len]='1';
    //if number of 1's are odd then 1 is added as parity bit at the end.

    str[len+1]='\0'; //terminating char array.

    printf("%s\n",str); //Printing the output.
}




int main(int argc,char *argv[])
{

    char str[30];
    strcpy(str,argv[1]);
    //copying argv[1] to character array to perform operations on it.
    int len=strlen(str);
    //strlen is used to calculate length of string.
    parity(str,len);
    //This function does working of parity bits.
    //bit_framing(str,len);
    //This function does working for bit_framing.
    return 0;
}