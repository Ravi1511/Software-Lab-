#include <stdio.h>
#include <string.h> //header file included for char arr 
#include <stdlib.h> // header file for strlen and strtol function


int substring(char *query,char *str,int n)
{
    int count1=strlen(str); //determining length of string
    int count2=strlen(query); //determining length of substring
    int counter=0,flag=0,i,j;

    ///This loop determines whether substring is contained by string or not
    for(i=0; i<=count1-count2; i++)
    {
        for(j=i; j<i+count2; j++)
        {
            flag=1;
            if(str[j]!=query[j-i])
            {
                flag=0;
                break;
            }
        }

        if(flag==1)
            break;
    }

    ///variable counter stores the number of strings containing substrings.
    if(flag==1)
        counter++;

    return counter;
}


void check_string(int n,int q)
{
    char str[n][30],query[q][10];
    int n1=0;

    //Reading all strings
    for(int i=0; i<n-1; i++)
    {
        scanf("%s\n",str[i]);
        int l1=strlen(str[i]);
        //printf("%d ",l1);
    }

    //Reading all substrings to be checked
    for(int i=0; i<q; i++)
    {
        scanf("%s\n",query[i]);
        int l2=strlen(query[i]);
       // printf("%d ",l2);
    }

    int i=0,j=0;
    //Iterating over all substrings and passing all strings to check whether it
    // matched or not
    while(i<q)
    {   
    	j=0,n1=0;
    	while(j<n)
    	{

        n1 += substring(query[i],str[j],n);
        //This function checks substring in all strings
        j++;
        }

        i++;

        printf("Q%d= %d\n",i,n1+1);
    }

}



int main(int argc, char *argv[])
{

    //converting command line arguments into integers by using strtol
    if(argc!=3)
    {
    	printf("Exiting now\n");
    	exit(1);
    }
    int n= strtol(argv[1],NULL,10);
    int q= strtol(argv[2],NULL,10);
    check_string(n,q);
    //check string is a function which checks for substring in a string.
    return 0;

}