var searchData=
[
  ['substring',['substring',['../ps1_8c.html#a0d8ba4100a2a3fbd13ff9f65bcc0d0a3',1,'ps1.c']]]
];
