var searchData=
[
  ['stack_5fnode',['stack_node',['../structstack__node.html',1,'']]]
];
