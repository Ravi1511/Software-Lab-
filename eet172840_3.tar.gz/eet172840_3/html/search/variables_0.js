var searchData=
[
  ['data',['data',['../structstack__node.html#a9eab91667db4d35c7231dcddf7b89a76',1,'stack_node']]]
];
