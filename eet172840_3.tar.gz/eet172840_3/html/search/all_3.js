var searchData=
[
  ['substring',['substring',['../ps1_8c.html#a360a38e4065dab8949e460ae47233ba8',1,'ps1.c']]]
];
