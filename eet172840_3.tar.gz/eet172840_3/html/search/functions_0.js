var searchData=
[
  ['check_5fstring',['check_string',['../ps1_8c.html#a4ccacae0b2155735baa2ad418b32eb79',1,'ps1.c']]]
];
