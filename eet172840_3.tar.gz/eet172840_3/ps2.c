#include <stdio.h>
#include <string.h>//header file to include char arr and strlen
#include <stdlib.h>// header file to include strtok

int main(int argc,char *argv[])
{

    int ip1[4],ip2[4],i=0,j=0,k=0,flag=0;
    char *token1=strtok(argv[1],".");
    /*< strtok is converting argv[1] to stream of tokens
    till we get "." to separate two tokens */

    while(token1!=NULL)
    {
        ip1[i]=strtol(token1,NULL,10);
        // storing tokens of argv[1] to ip1 array after
        // converting it to integers.
        token1 = strtok(NULL,".");
        i++;
    }

    char *token2=strtok(argv[2],".");
    // converting argv[2] into tokens separated by .
    while(token2!=NULL)
    {
        ip2[j++]=strtol(token2,NULL,10);
        // using strtol to convert char arr to integers.
        token2 = strtok(NULL,".");
    }



    //iterating through all 4 octets which are separated
    //through . to compare ip address
    while(k<4)
    {
        if(ip1[k]>ip2[k])
            // Looking for first octet for comparison and so on
        {
            printf("1\n");
            //if ip1 is greater than ip2 then return 1.
            flag=1;
            break;
        }
        else if(ip1[k]<ip2[k])
        {
            printf("-1\n");
            //if ip2 is greater than ip1 then return -1.
            flag=1;
            break;
        }
        else
            k++; //otherwise iterate over next octet.
    }

    if(k==4 && flag==0)
        //If iterated over all octets and prevoious octets were same
        //then print 0 since both ip are equal.
        printf("0\n");

    return 0;
}