#!/bin/sh

#Enter the choice for user to input
echo "Enter number:"
echo "1 for Changing file permission rwx(111) for owner and rx(101) for others"
echo "2 for create/delete test user,change owner to test user "
echo "3 Change date accessed/modified for any file/directory"
echo "4 hide all files/folders for a particular user"
echo "5 count number of vowels from a file"
# readind chioce enteed by user
read choice

case $choice in
  1)
    #enter the file to change permission
    read -p "Enter the filename: " FILE
    if [ -f "$FILE" ];
	then
	# changing to rwx for owner and rx for others
	sudo chmod 755 $FILE && echo "Permission changed succesfully "
	else
	#error message if file does not exist
    echo "File $FILE does not exist" >&2
	fi
    ;;

  2)
    #read username and user.txt file to check if exists
	read -p "Enter username : " username
	read -p "Enter filename : " FILE
	#check whether username exist in file user.txt or not
	if grep -q $username "$FILE"; then
	    if [ $(id -u) -eq 0 ]; then
	    #enter username and password to create a username
		read -p "Enter username : " username
		read -s -p "Enter password : " password
		egrep "^$username" /etc/passwd >/dev/null
			if [ $? -eq 0 ]; then
				#username already exists here
				echo "$username already exists!"
				exit 1
			else
				#username does not exist but present in user/txt file so create it
				pass=$(perl -e 'print crypt($ARGV[0], "password")' $password)
				useradd -m -p $pass $username
				[ $? -eq 0 ] && echo "User has been added to system!" || echo "Failed to add a user!"
			fi
		else
		#error message if user is not admin
		echo "Only root may add a user to the system"
		exit 2
		fi
	else
		#error message if user does nto exist in user.txt file
		echo "User does not exist in user.txt"

	fi
  ;;

  3)
    #Enter the file name to change date acceses and date modified
    read -p "Enter the filename: " FILE
    #enter the date accesesd file name
    read -p "Emter date access with format '11 Mar 1993 11:40' " date_access
    #enter the date modified file name
    read -p "Emter date modifed:  " date_modify
    #enter the new date accesed
    touch -m -d "$date_access " $FILE
    #enter the new date modified
    touch -a -d "$date_modify " $FILE
    ;;


  4)
    #enter the file to hide
    read -p "Enter the filename" FILE
    #enter the username and password from whom to hode files or folders
    read -p "Enter username : " username
	read -s -p "Enter password : " password
    egrep "^$username" /etc/passwd >/dev/null
    #if username exists then hide the files from him
	if [ $? -eq 0 ]; then
		mv $FILE .$FILE
		echo "File is hidden for $username"
		exit 1
	else
		echo "Username does not exist"
		exit 2
	fi
    ;;

   5)
    # Enter the file name to check for vowels
	read -p "Enter the filename : " FILE
	echo "Vowels are"
	#command to check number of vowels
	vow= cat $FILE | grep -o "[aAeEiIoOuU]" |wc -l
	#bonus port
	# entering the data timestamp and number of vowels in log.txt file
	cat <<EOT >> log.txt
	echo "vowels "$(cat $FILE | grep -o "[aAeEiIoOuU]" |wc -l)
	$(date "+%Y.%m.%d-%H.%M.%S")
EOT
    ;;

  *)
   #wrong choice
    echo "It's something else!"
    ;;
	esac
    #ending shell script
    echo "End of script."
