#!/bin/sh

#Enter Choice available for user
echo "Enter number:"
echo "1 for Employee/Owner"
echo "2 for Customer"
echo "Enter: "
read choice


	case $choice in
	1)
	#calculating selling price for items
	#which are present in inventory.txt
	while IFS=" " read -r v1 v2 v3 v4
	do 
	   #This loop calculating selling price
	   #for each product.
	   echo"selling values are: "
	   p=`echo $v2\*$v3|bc`
	   profit=`echo $p/100|bc`
	   value=`echo $v2+$profit|bc`
	   echo "$value"
	done < "Inventory.txt"

    ;;


    2)
    #Check if employee is owner or ordinary employee
    echo "Enter number:"
	echo "1 for Employee"
	echo "2 for Owner"
	read choice2
	#If employee is ordinary employee then will have limited previleges.
	if[ $choice2 == 1 ]	
	#Enter username and password in secret format	
    read -p "Enter username : " username
	read -s -p "Enter password : " password
	USERPW=`grep "^$password:" /etc/passwd | cut -d: -f2`
		if [ ! -z "${USERPW}" ];then
		#encrypting password in secret format
		ENCRPW=`perl -e "print crypt(${PASSWORD},${USERPW})"`
			if [ "${USERPW}" = "${ENCRPW}" ];then
			echo "Password Entered is Correct"
			else
			echo "Password Entered is Wrong"
			fi
		else
		echo "No Such User Exists"
		fi
	  
      
    
     
   
    elif[ $choice2 == 2 ]
    #If employee is owner then will have all previleges
    read -p "Enter username : " username
	read -s -p "Enter password : " password
	USERPW=`grep "^$password:" /etc/passwd | cut -d: -f2`
		if [ ! -z "${USERPW}" ];then
		#encrypting password in secret format
		ENCRPW=`perl -e "print crypt(${PASSWORD},${USERPW})"`
			if [ "${USERPW}" = "${ENCRPW}" ];then
			echo "Password Entered is Correct"
			else
			echo "Password Entered is Wrong"
			fi
		else
		echo "No Such User Exists"
		fi
    
   
   
    ;;
	
   3)
  #No username and password asked for customer
   echo "customer buy and checkout"
    ;;

  *)
   #wrong choice
    echo "Wrong choice"
    ;;
	esac
    #ending shell script
    echo "End of script."

