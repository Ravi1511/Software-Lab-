#!/bin/sh

# Author : Zara Ali
# Copyright (c) Tutorialspoint.com
# Script follows here:

#echo "What is your name?"
#read PERSON
#echo "Hello, $PERSON"


read -p "Enter the filename" test.txt


#file=$1
#v=0
 
 if [ $# -ne 1 ]
then
 echo "$0 fileName"
 exit 1
fi
if [ ! -f $file ]
then
 echo "$test.txt not a file"
 exit 2
fi