#include <stdio.h>



//this function calculate total profit earned
int profit_earned(int n,int k,int a[])
{
   int count=0,profit=0;
	for(int i=0;i<n;i++)
	{ 
		if(a[i]<=0) //if arrival time is negative or zero then increment count
	    	count++;
	}
	if(count>=k)  //if count crosses threshold value k then profit will be 100*count
	profit=100*count;
	else
	profit=0; //no profit when count is less than k
   return profit;
}


int main()
{
   
   int n,k,ans; 
   scanf("%d %d",&n,&k); //scan first line of input n=passenger,k=threshold
   int a[n];
	
	for(int i=0;i<n;i++)
	scanf("%d",&a[i]);  //storing arrival time of passengers in an array
   
   ans=profit_earned(n,k,a);//this function returned answer.
   printf("%d\n",ans);
   return 0;
}
