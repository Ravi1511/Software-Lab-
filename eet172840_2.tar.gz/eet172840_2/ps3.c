#include<stdio.h>
#include <stdlib.h> //header file for strtol


//this function returns number of bits required for x variable.
int convt(int x)
{

    if(x==0)
        return 0;
    else
        // this formula returns number of bits and runs recursively.
        return (x%2+10*convt(x/2));
}




//main function begins here
int main(int argc,char *argv[])
{

    int a[argc],x=0,n=0,temp=argc-1;
    
    //strtol function returns char string to integer.
    for(int i=0; i<argc; i++)
        a[i]=strtol(argv[i],NULL,10);


    // this loop runs over number of arguments t ocount 0 and 1 in strings.
    for(int i=1; i<argc; i++)
    {
        int count_0=0,count_1=0;
        
        //if array contains 1 then increment counter of 1.
        if(a[i]==1)
        {
            count_1++;
            while(a[i++]==1)
                count_1++;
            
            //n contains consecutive number of 1's
		    n = convt(count_1);
		    // x variable sums all number of 1's
            x += n;
           
        }
        

        //if array contains 0 then increment counter of 0.
        if(a[i]==0)
        {
            count_0++;
            while(a[i++]==0)
            	count_0++;
                
            //n contains consecutive number of 0's
            n=convt(count_0);
            // x variable sums all number of 0's
            x += n;
         
        }
        

        printf("\nCompression Ratio= %d:%d \n",x,temp);
        //if required bits are less than total input string length
        //then code is efficient otherwise code is inefficient.
        if(x<temp)
        	printf("Efficient Scheme for code\n");
        else
        	printf("Not Efficient Scheme for code\n");

        return 0;
    }




}
