#include<stdio.h>
#include<stdlib.h>// header file used for strtol function

//Function to compute total cost
int total_cost(int a[],int n)
{
    int base_price=4000;
    int total_cost=0;
    int month=(a[2]-a[5]);
    if(month<0)                    //if year changes then we handle by this
        month=12-(a[5]-a[2]);
    int days=(a[1]-a[4]);
    if(days<0)
        days=30-(a[1]-a[4]);

    if(month>=3 || month==3 && days==0)
        /*if difference between month is greater than or
         equal to 3 months then no increase in total cost*/
        return base_price;

    else //if difference is less than 3 months
    {
        int temp=((12/(month+1))+(days/30));
        int extra=(temp*base_price)/100; //calculating extra charge on base fare
        int conv_charge=(12*base_price)/100; //calculating convenience charge
        int GST=(30*base_price)/100; //calculating GST charge
        int total_cost=base_price+extra+conv_charge+GST; //Add all to find total cost
        return total_cost;
    }

}


int main(int argc,char *argv[])
{
    if(argc!=7)//if input format is wrong
    {
        printf("Improper format\n");
        return 0;
    }
    int a[argc],ans;
    for(int i=0; i<argc; i++)
        a[i]=strtol(argv[i],NULL,10); //strtol is used to convert char to integer.
    ans=total_cost(a,argc); //total_cost function returns total cost.
    printf("%d\n",ans);
    return 0;

}
